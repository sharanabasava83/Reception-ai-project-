class DBManager:
 async def initialize(self): pass
 async def close(self): pass

db_manager=DBManager()
